package com.example.fit2081assignment1.providerEvent;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;


import java.util.List;

public class EventViewModel extends AndroidViewModel {

    private EventRepository mRepository;
    private LiveData<List<EventItem>> mAllEvent;

    public EventViewModel(@NonNull Application application) {
        super(application);
        mRepository = new EventRepository(application);
        mAllEvent = mRepository.getAllEvent();
    }
    public LiveData<List<EventItem>> getAllEvent() {
        return mAllEvent;
    }

    public void insert(EventItem eventItem) {
        mRepository.insert(eventItem);
    }
    public void deleteAll(){
        mRepository.deleteAll();
    }

}
