package com.example.fit2081assignment1.provider;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

public class CategoryRepository {

    private CategoryDao mCategoryDao;
    private LiveData<List<CategoryItem>> mAllCategory;

    CategoryRepository(Application application){
        CategoryDatabase db = CategoryDatabase.getDatabase(application);
        mCategoryDao = db.categoryDao();
        mAllCategory = mCategoryDao.getAllCategory();
    }
    LiveData<List<CategoryItem>> getAllCategory() {
        return mAllCategory;
    }
    void insert(CategoryItem categoryItem) {
        CategoryDatabase.databaseWriteExecutor.execute(() -> mCategoryDao.addCategory(categoryItem));
    }
    void deleteAll(){
        CategoryDatabase.databaseWriteExecutor.execute(()->{
            mCategoryDao.deleteAllCategories();
        });
    }
    void addEventCount(int eventCount){
        CategoryDatabase.databaseWriteExecutor.execute(()->{
            mCategoryDao.getCategoryEventCount(eventCount);
        });
    }

    void updateCategory(CategoryItem categoryItem){
        CategoryDatabase.databaseWriteExecutor.execute(()->
            mCategoryDao.updateCategory(categoryItem)
        );
    }

}
