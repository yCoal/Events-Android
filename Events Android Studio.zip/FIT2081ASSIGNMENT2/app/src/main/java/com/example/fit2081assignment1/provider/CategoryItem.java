package com.example.fit2081assignment1.provider;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName =  CategoryItem.TABLE_NAME)
public class CategoryItem {
    public static final String TABLE_NAME = "categories";
    @PrimaryKey(autoGenerate = true)
    @NonNull
    @ColumnInfo(name = "CategoryPKId")
    private int id;
    @ColumnInfo(name = "CategoryId")
    private String categoryId;
    @ColumnInfo(name = "CategoryName")
    private String categoryName;
    @ColumnInfo(name = "CategoryEventCount")
    private int categoryEventCount;
    @ColumnInfo(name = "IsActive")
    private boolean isActive;
    @ColumnInfo(name = "CategoryLocation")
    private String location;

    public CategoryItem(String categoryId, String categoryName,  int categoryEventCount, boolean isActive, String location) {
        this.categoryId = categoryId;
        this.categoryName = categoryName;
        if (categoryEventCount < 0){
            this.categoryEventCount = 0;
        }else{
            this.categoryEventCount = categoryEventCount;
        }

        this.isActive = isActive;
        this.location = location;
    }
    public int getId(){return id;}
    public void setId(@NonNull int id) {
        this.id = id;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public int getCategoryEventCount() {
        return categoryEventCount;
    }

    public boolean getIsActive() {
        return isActive;
    }
    public void addCount(int int1){
        this.categoryEventCount += int1;
    }
    public String getLocation(){
        return location;
    }

    public void setCategoryEventCount(int categoryEventCount) {
        this.categoryEventCount = categoryEventCount;
    }

}
