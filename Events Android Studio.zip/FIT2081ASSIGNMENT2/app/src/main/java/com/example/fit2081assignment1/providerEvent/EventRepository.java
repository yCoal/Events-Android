package com.example.fit2081assignment1.providerEvent;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

public class EventRepository {


    private EventDao mEventDao;
    private LiveData<List<EventItem>> mAllEvents;

    EventRepository(Application application){
        EventDatabase db = EventDatabase.getDatabase(application);
        mEventDao = db.eventDao();
        mAllEvents = mEventDao.getAllEvent();
    }
    LiveData<List<EventItem>> getAllEvent() {
        return mAllEvents;
    }
    void insert(EventItem categoryItem) {
        EventDatabase.databaseWriteExecutor.execute(() -> mEventDao.addEvent(categoryItem));
    }
    void deleteAll(){
        EventDatabase.databaseWriteExecutor.execute(()->{
            mEventDao.deleteAllEvents();
        });
    }

//    void getName(EventItem categoryItem) {
//        EventDatabase.databaseWriteExecutor.execute(() -> mEventDao.getEvent(categoryItem));
//    }

}
