package com.example.fit2081assignment1;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    String passwordInput;
    String passwordConfirmInput;
    String userName;
    EditText tvUserName;
    EditText tvPasswordInput;
    EditText tvPasswordConfirm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        registerReceiver(new SMSReceiver(),new IntentFilter("android.provider.Telephony.SMS_RECEIVED"),RECEIVER_EXPORTED);

        tvUserName = findViewById(R.id.etUsername);
        tvPasswordInput = findViewById(R.id.etPassword);
        tvPasswordConfirm = findViewById(R.id.etPasswordConfirm);

    }

    public void onNextClickLogin (View view){

        Intent intent = new Intent(this, LoginMenu.class);

        startActivity(intent);
    }

    public void onNextClickSignUp (View view){
        userName = tvUserName.getText().toString();
        passwordInput = tvPasswordInput.getText().toString();
        passwordConfirmInput = tvPasswordConfirm.getText().toString();


        if (passwordInput.equals(passwordConfirmInput)){
            Toast.makeText(getApplicationContext(), "Login Was Successful",Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, LoginMenu.class);
            saveDataToSharedPreference(userName, passwordInput);
            startActivity(intent);
        }
        else {
            Toast.makeText(getApplicationContext(), "Login Was Not Successful", Toast.LENGTH_SHORT).show();
        }

    }

    private void saveDataToSharedPreference(String userName, String passwordInput){

        SharedPreferences sharedPreferences = getSharedPreferences("UNIQUE_FILE_NAME", MODE_PRIVATE);

        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString("KEY_USERNAME", userName);
        editor.putString("KEY_PASSWORD", passwordInput);
        editor.apply();
    }
}