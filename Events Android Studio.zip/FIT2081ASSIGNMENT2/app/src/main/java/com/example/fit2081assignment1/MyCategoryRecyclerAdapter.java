package com.example.fit2081assignment1;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fit2081assignment1.provider.CategoryItem;

import java.util.ArrayList;
import java.util.List;

public class MyCategoryRecyclerAdapter extends RecyclerView.Adapter<MyCategoryRecyclerAdapter.CategoryCustomViewHolder>{

    private List<CategoryItem> mCategory;
//    ArrayList<CategoryItem> categoryData;
//    public void setData(ArrayList<CategoryItem> categoryData) {
//        this.categoryData = categoryData;
//    }
    @NonNull
    @Override
    public CategoryCustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_layout_all_category, parent, false); //CardView inflated as RecyclerView list item
        CategoryCustomViewHolder viewHolder = new CategoryCustomViewHolder(v);
        return viewHolder;
    }

    public void onBindViewHolder(@NonNull CategoryCustomViewHolder holder, int position) {
        holder.tvCategoryId.setText(String.valueOf(mCategory.get(position).getCategoryId()));
        holder.tvCategoryName.setText(String.valueOf(mCategory.get(position).getCategoryName()));
        holder.tvCategoryEventCount.setText(String.valueOf(mCategory.get(position).getCategoryEventCount()));
        holder.tvIsActive.setText(String.valueOf(mCategory.get(position).getIsActive()));
        holder.tvLocation.setText(String.valueOf(mCategory.get(position).getLocation()));

        holder.cardView.setOnClickListener(v -> {
            String selectedCategoryCountry = mCategory.get(position).getLocation();

            // TODO: Launch new MapsActivity with Country Name in extras
            Context context = holder.cardView.getContext();
            Intent intent = new Intent(context, GoogleMapActivity.class);
            intent.putExtra("CategoryCountry", selectedCategoryCountry);
            context.startActivity(intent);
        });
    }

    public int getItemCount() {
        if (this.mCategory != null) {
            return this.mCategory.size();
        }
        return 0;
    }

    public void setCategory(List<CategoryItem> newData){
        mCategory = newData;
    }

    public class CategoryCustomViewHolder extends RecyclerView.ViewHolder {

        public TextView tvCategoryName, tvCategoryId, tvCategoryEventCount, tvIsActive, tvLocation;

        public View cardView;
        public CategoryCustomViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView;
            tvCategoryId = itemView.findViewById(R.id.tv_category_id);
            tvCategoryName = itemView.findViewById(R.id.tv_category_name);
            tvCategoryEventCount = itemView.findViewById(R.id.tv_category_event_count);
            tvIsActive = itemView.findViewById(R.id.tv_category_is_active);
            tvLocation = itemView.findViewById(R.id.tv_category_location);
        }
    }
}
