package com.example.fit2081assignment1.providerEvent;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = EventItem.TABLE_NAME)
public class EventItem {
    public static final String TABLE_NAME = "events";

    @PrimaryKey(autoGenerate = true)
    @NonNull
    @ColumnInfo(name = "EventPKId")
    private int id;
    @ColumnInfo(name = "EventName")
    private String eventName;
    @ColumnInfo(name = "EventId")

    private String eventId;
    @ColumnInfo(name = "CategoryId")

    private String categoryId;
    @ColumnInfo(name = "EventTickets")

    private int eventTicketsAvailable;
    @ColumnInfo(name = "EventIsActive")

    private boolean eventIsActive;

    public EventItem(String eventId, String eventName,  String categoryId, int eventTicketsAvailable, boolean eventIsActive) {
        this.eventName = eventName;
        this.eventId = eventId;
        this.categoryId = categoryId;
        this.eventTicketsAvailable = eventTicketsAvailable;
        this.eventIsActive = eventIsActive;
    }
    public int getId(){return id;}
    public void setId(@NonNull int id) {
        this.id = id;
    }
    public String getEventName() {
        return eventName;
    }

    public String getEventId() {
        return eventId;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public int getEventTicketsAvailable() {
        return eventTicketsAvailable;
    }

    public boolean eventIsActive() {
        return eventIsActive;
    }
}
