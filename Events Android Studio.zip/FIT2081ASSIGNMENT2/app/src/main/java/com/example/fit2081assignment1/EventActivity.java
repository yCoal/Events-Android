package com.example.fit2081assignment1;

import static java.lang.Integer.parseInt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import java.util.Random;

public class EventActivity extends AppCompatActivity {

    String newCategoryName;
    String newCategoryId;
    int newTicketNumber;
    EditText tvNewCategoryName;
    EditText tvNewCategoryId;
    EditText tvNewTicketNumber;
    EditText tvNewEventId;
    Switch newSwitchActive;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event);

        tvNewCategoryName = findViewById(R.id.etNewEventName);
        tvNewCategoryId = findViewById(R.id.etNewCategoryId);
        tvNewTicketNumber = findViewById(R.id.etNewTicketNumber);
        newSwitchActive = findViewById(R.id.newSwitchActive);

        tvNewEventId = findViewById(R.id.etNewEventId);

        MyBroadCastReceiver myBroadCastReceiver = new MyBroadCastReceiver();

        registerReceiver(myBroadCastReceiver, new IntentFilter(SMSReceiver.SMS_FILTER), RECEIVER_EXPORTED);

    }

    public void onClickNew (View view){

        int lowerBound = 1000;
        int upperBound = 9999;

        newCategoryName = tvNewCategoryName.getText().toString();
        newCategoryId = tvNewCategoryId.getText().toString();
        newTicketNumber = parseInt(tvNewTicketNumber.getText().toString());

        Random r = new Random();
        char randomChar = (char) (r.nextInt(26) + 'a');
        char randomUpperCaseChar = Character.toUpperCase(randomChar);

        char randomChar2 = (char) (r.nextInt(26) + 'a');
        char randomUpperCaseChar2 = Character.toUpperCase(randomChar2);

        int random_num = (int) (Math.random() * (upperBound - lowerBound + 1)) + lowerBound;

        if(newCategoryName != "" && newCategoryId != "" && newTicketNumber > 0){
            String newEventIdOutput = "E" + + randomUpperCaseChar + randomUpperCaseChar2 + "-" + random_num;
            Toast.makeText(getApplicationContext(), "Event saved: " + newEventIdOutput,Toast.LENGTH_LONG).show();
            tvNewEventId.setText(newEventIdOutput);
            saveDataToSharedPreference(newCategoryName, newCategoryId, newTicketNumber,newEventIdOutput);
        }else {
            Toast.makeText(getApplicationContext(), "Please Enter A Proper Name, ID and Ticket Number", Toast.LENGTH_LONG).show();
        }

    }

    private void saveDataToSharedPreference(String newCategoryNameSave, String newCategoryIdSave, int newTicketNumber, String newEventIdSave) {

        SharedPreferences sharedPreferences = getSharedPreferences("UNIQUE_FILE_NAME", MODE_PRIVATE);

        SharedPreferences.Editor editor = sharedPreferences.edit();

        boolean isActiveBool = newSwitchActive.isChecked();

        editor.putString("KEY_NEW_CATEGORY_NAME", newCategoryNameSave);
        editor.putString("KEY_NEW_CATEGORY_ID", newCategoryIdSave);
        editor.putBoolean("KEY_NEW_SWITCH_BOOL", isActiveBool);
        editor.putInt("KEY_NEW_TICKET_NUMBER", newTicketNumber);
        editor.putString("KEY_NEW_EVENT_ID", newEventIdSave);

        editor.apply();
    }



    class MyBroadCastReceiver extends BroadcastReceiver {


        @Override
        public void onReceive(Context context, Intent intent) {

            String msg = intent.getStringExtra(SMSReceiver.SMS_MSG_KEY);

                if(msg != null){

                    if(msg.startsWith("event")){
                        msg = msg.substring("event:".length());

                        String [] split_string_new = msg.split(";", 4);

                        String categoryNameNewMsg = split_string_new[0];
                        String categoryIdNewMsg = split_string_new[1];
                        String ticketCountMsg = split_string_new[2];
                        String switchStateNewMsg = split_string_new[3];

                        if (split_string_new.length == 4){
                            if (categoryNameNewMsg != "" && categoryIdNewMsg !="" && ticketCountMsg != ""){

                                try {
                                    int ticketCountMsgInt;
                                    ticketCountMsgInt = Integer.parseInt(ticketCountMsg);

                                    tvNewCategoryName.setText(categoryNameNewMsg);
                                    tvNewCategoryId.setText(categoryIdNewMsg);
                                    tvNewTicketNumber.setText(ticketCountMsg);
                                    Toast.makeText(context, "event: " + categoryNameNewMsg + " " + categoryIdNewMsg + " " + ticketCountMsg + " " + switchStateNewMsg, Toast.LENGTH_LONG).show();
                                    if (switchStateNewMsg.equalsIgnoreCase("true")) {
                                        newSwitchActive.setChecked(true);
                                    } else if (switchStateNewMsg.equalsIgnoreCase("false")) {
                                        newSwitchActive.setChecked(false);

                                    }

                                    }catch (NumberFormatException e) {
                                    if (!categoryIdNewMsg.equals("") || !ticketCountMsg.equals("")){
                                        Toast.makeText(context, "Invalid Message", Toast.LENGTH_SHORT).show();
                                    }else{
                                        if (switchStateNewMsg.equalsIgnoreCase("true")) {
                                            newSwitchActive.setChecked(true);
                                        } else if (switchStateNewMsg.equalsIgnoreCase("false")) {
                                            newSwitchActive.setChecked(false);

                                        }
                                    }

                                }
                            }
                        }
                    }
                }


        }
    }
}