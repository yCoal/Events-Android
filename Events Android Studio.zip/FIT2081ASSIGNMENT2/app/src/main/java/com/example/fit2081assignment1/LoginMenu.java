package com.example.fit2081assignment1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LoginMenu extends AppCompatActivity {

    String usernameRestored;
    String passwordRestored;
    EditText tvusernameLogin;
    EditText tvpasswordLogin;
    String usernameInputLogin;
    String passwordInputLogin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_menu);


        SharedPreferences sharedPreferences = getSharedPreferences("UNIQUE_FILE_NAME", MODE_PRIVATE);

        usernameRestored = sharedPreferences.getString("KEY_USERNAME", "");
        passwordRestored = sharedPreferences.getString("KEY_PASSWORD", "");

        tvusernameLogin = findViewById(R.id.etUsernameLogin);
        tvpasswordLogin = findViewById(R.id.etPasswordLogin);

    }

    public void onClickLogin(View view){

        usernameInputLogin = tvusernameLogin.getText().toString();
        passwordInputLogin = tvpasswordLogin.getText().toString();

        if (usernameInputLogin.equals(usernameRestored) && passwordInputLogin.equals(passwordRestored)){
            Toast.makeText(getApplicationContext(), "Redirecting...", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, Dashboard.class);
            saveDataToSharedPreference(usernameInputLogin, passwordInputLogin);
            startActivity(intent);
        }
        else{
            Toast.makeText(getApplicationContext(), "Username Or Password Incorrect", Toast.LENGTH_SHORT).show();
        }
    }

    public void onClickBack (View view){
        Intent intent = new Intent(this, MainActivity.class);

        startActivity(intent);
    }

    private void saveDataToSharedPreference(String userName, String passwordInput){

        SharedPreferences sharedPreferences = getSharedPreferences("UNIQUE_FILE_NAME", MODE_PRIVATE);

        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString("KEY_USERNAME_LOGIN", userName);
        editor.putString("KEY_PASSWORD_LOGIN", passwordInput);
        editor.apply();
    }

}