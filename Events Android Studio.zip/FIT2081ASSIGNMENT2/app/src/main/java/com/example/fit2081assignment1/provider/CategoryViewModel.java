package com.example.fit2081assignment1.provider;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class CategoryViewModel extends AndroidViewModel {
    private CategoryRepository mRepository;
    private LiveData<List<CategoryItem>> mAllCategory;

    public CategoryViewModel(@NonNull Application application) {
        super(application);
        mRepository = new CategoryRepository(application);
        mAllCategory = mRepository.getAllCategory();
    }
    public LiveData<List<CategoryItem>> getAllCategory() {
        return mAllCategory;
    }
    public void insert(CategoryItem categoryItem) {
        mRepository.insert(categoryItem);
    }
    public void deleteAll(){
        mRepository.deleteAll();
    }
    public void update(CategoryItem categoryItem){
        mRepository.updateCategory(categoryItem);
    }

}
