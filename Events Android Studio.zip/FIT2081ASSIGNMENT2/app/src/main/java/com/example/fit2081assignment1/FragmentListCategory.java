package com.example.fit2081assignment1;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.fit2081assignment1.provider.CategoryItem;
import com.example.fit2081assignment1.provider.CategoryViewModel;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FragmentListCategory#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FragmentListCategory extends Fragment {

    private RecyclerView recyclerView;
    private CategoryViewModel mCategoryViewModel;
    RecyclerView.LayoutManager layoutManager;
    MyCategoryRecyclerAdapter adapter;
    ArrayList<CategoryItem> categoryItems;

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public FragmentListCategory() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment CategoryFragment.
     */

    public static FragmentListCategory newInstance(String param1, String param2) {
        FragmentListCategory fragment = new FragmentListCategory();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_category, container, false);
        recyclerView = view.findViewById(R.id.category_recycle_view);
        MyCategoryRecyclerAdapter adapter = new MyCategoryRecyclerAdapter();
        recyclerView.setAdapter(adapter);
        layoutManager = new LinearLayoutManager(view.getContext());
        recyclerView.setLayoutManager(layoutManager);

        mCategoryViewModel = new ViewModelProvider(this).get(CategoryViewModel.class);
        mCategoryViewModel.getAllCategory().observe(this, newData -> {
//            adapter = new MyCategoryRecyclerAdapter();
            adapter.setCategory(newData);
            adapter.notifyDataSetChanged();
//            tv.setText(newData.size() + "");
        });
        return view;


//        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("NEW_CATEGORY", Context.MODE_PRIVATE);
//        SharedPreferences.Editor editor = sharedPreferences.edit();
//
//        String json = sharedPreferences.getString("EVENT_CATEGORY", null);
//        Gson gson = new Gson();
//        Type type = new TypeToken<ArrayList<CategoryItem>>() {}.getType();
//        categoryItems = gson.fromJson(json, type);

//        return view;
    }

}