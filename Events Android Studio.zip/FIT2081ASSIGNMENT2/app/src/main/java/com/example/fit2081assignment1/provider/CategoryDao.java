package com.example.fit2081assignment1.provider;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface CategoryDao {


    @Query("select * from categories")
    LiveData<List<CategoryItem>> getAllCategory();

    @Query("select * from categories where CategoryName=:name")
    List<CategoryItem> getCategory(String name);

    @Insert
    void addCategory(CategoryItem categoryItem);

    @Query("delete from categories where CategoryName=:name")
    void deleteCustomer(String name);

    @Query("delete FROM categories")
    void deleteAllCategories();

    @Query("select * from categories where CategoryEventCount=:categoryEventCount")
    List<CategoryItem> getCategoryEventCount(int categoryEventCount);

    @Update
    void updateCategory(CategoryItem categoryItem);
}
