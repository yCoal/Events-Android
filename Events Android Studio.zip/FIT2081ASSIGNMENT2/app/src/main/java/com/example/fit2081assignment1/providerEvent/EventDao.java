package com.example.fit2081assignment1.providerEvent;


import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;


import java.util.List;

@Dao
public interface EventDao {

    @Query("select * from events")
    LiveData<List<EventItem>> getAllEvent();

    @Query("select * from events where EventName=:name")
    List<EventItem> getEvent(String name);

    @Insert
    void addEvent(EventItem eventItem);

    @Query("delete from events where EventName=:name")
    void deleteEvent(String name);

    @Query("delete FROM events")
    void deleteAllEvents();


}

