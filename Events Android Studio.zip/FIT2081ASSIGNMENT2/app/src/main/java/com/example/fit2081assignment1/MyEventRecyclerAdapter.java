package com.example.fit2081assignment1;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fit2081assignment1.providerEvent.EventItem;

import java.util.List;

public class MyEventRecyclerAdapter extends RecyclerView.Adapter<MyEventRecyclerAdapter.EventCustomViewHolder> {

    private List<EventItem> mEvent;
//    ArrayList<EventItem> eventData = new ArrayList<EventItem>();
//    public void setData(ArrayList<EventItem> categoryData) {
//        this.eventData = categoryData;
//    }

    @NonNull
    @Override
    public EventCustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_layout_all_event, parent, false); //CardView inflated as RecyclerView list item
        EventCustomViewHolder viewHolder = new EventCustomViewHolder(v);
        return viewHolder;
    }

    public void onBindViewHolder(@NonNull MyEventRecyclerAdapter.EventCustomViewHolder holder, int position) {
        holder.tvEventName.setText(String.valueOf(mEvent.get(position).getEventName()));
        holder.tvEventId.setText(String.valueOf(mEvent.get(position).getEventId()));
        holder.tvCategoryIdInEvent.setText(String.valueOf(mEvent.get(position).getCategoryId()));
        holder.tvEventTicketsAvailable.setText(String.valueOf(mEvent.get(position).getEventTicketsAvailable()));
        if (mEvent.get(position).eventIsActive()) {
            holder.tvIsActive.setText("Available");
        } else {
            holder.tvIsActive.setText("Unavailable");
        }

        holder.cardView.setOnClickListener(v -> {
            String selectedCategoryCountry = mEvent.get(position).getEventName();

            // TODO: Launch new MapsActivity with Country Name in extras
            Context context = holder.cardView.getContext();
            Intent intent = new Intent(context, EventGoogleResult.class);
            intent.putExtra("countryName", selectedCategoryCountry);
            context.startActivity(intent);
        });
    }

    public int getItemCount() {
        if (this.mEvent != null) {
            return this.mEvent.size();
        }
        return 0;
    }

    public void setEvent(List<EventItem> newData){
        mEvent = newData;
    }

    public class EventCustomViewHolder extends RecyclerView.ViewHolder {

        public TextView tvEventName, tvEventId, tvCategoryIdInEvent, tvEventTicketsAvailable, tvIsActive;
        public View cardView;

        public EventCustomViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView;
            tvEventId= itemView.findViewById(R.id.tv_event_id);
            tvEventName = itemView.findViewById(R.id.tv_event_name);
            tvCategoryIdInEvent = itemView.findViewById(R.id.tv_event_category_id);
            tvEventTicketsAvailable= itemView.findViewById(R.id.tv_event_tickets_available);
            tvIsActive = itemView.findViewById(R.id.tv_event_is_active);
        }
    }

}
