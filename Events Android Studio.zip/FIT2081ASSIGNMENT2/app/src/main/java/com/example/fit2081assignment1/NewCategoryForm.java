package com.example.fit2081assignment1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import com.example.fit2081assignment1.provider.CategoryItem;
import com.example.fit2081assignment1.provider.CategoryViewModel;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Random;


public class NewCategoryForm extends AppCompatActivity {

    String categoryNameInput;
    String eventCountInput;
    String locationInput;
    boolean isActiveBool;
    EditText tvCategoryName;
    EditText tvEventCount;
    EditText tvCategoryId;
    EditText tvLocation;
    Switch activeSwitch;
    private MyBroadCastReceiver myBroadCastReceiver;
    private CategoryViewModel mCategoryViewModel;
    ArrayList<CategoryItem> categoryData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_category);

        tvCategoryName = findViewById(R.id.etCategoryName);
        tvEventCount = findViewById(R.id.etEventCount);
        activeSwitch = findViewById(R.id.isActiveSwitch);
        tvCategoryId = findViewById(R.id.etCategoryId);
        tvLocation = findViewById(R.id.etLocation);

        myBroadCastReceiver = new MyBroadCastReceiver();
        registerReceiver( myBroadCastReceiver,new IntentFilter(SMSReceiver.SMS_FILTER),RECEIVER_EXPORTED);

        mCategoryViewModel = new ViewModelProvider(this).get(CategoryViewModel.class);
    }


    public void onClickSaveCategory(View view) {
        categoryNameInput = tvCategoryName.getText().toString();
        eventCountInput = tvEventCount.getText().toString();
        isActiveBool = activeSwitch.isChecked();
        locationInput = tvLocation.getText().toString();
        int categoryCountInteger;
        try{
            categoryCountInteger = Integer.parseInt(eventCountInput);
        } catch (NumberFormatException e){
            categoryCountInteger = -1;
        }

        if (!categoryNameInput.isEmpty() && categoryCountInteger == -1 || categoryCountInteger>0) {
            String categoryIdString = categoryIdGenerator();
            tvCategoryId.setText(categoryIdString);
            CategoryItem c = new CategoryItem(categoryIdString,categoryNameInput, categoryCountInteger, isActiveBool, locationInput);
            Toast.makeText(this, "Category saved successfully:" + categoryIdString, Toast.LENGTH_SHORT).show();
            mCategoryViewModel.insert(c);
            finish();

//            saveDataToSharedPreference(categoryIdString, categoryNameInput, categoryCountInteger,isActiveBool);
        }else {
            Toast.makeText(this, "Please enter valid input", Toast.LENGTH_SHORT).show();
        }
    }


//    private void saveDataToSharedPreference(String categoryIdSave, String categoryNameSave, int eventCountSave, boolean isActiveBoolean) {
//
//        SharedPreferences sharedPreferences = getSharedPreferences("NEW_CATEGORY", MODE_PRIVATE);
//        SharedPreferences.Editor editor = sharedPreferences.edit();
//
//        String json = sharedPreferences.getString("EVENT_CATEGORY",  null);
//        CategoryItem categoryItem = new CategoryItem(categoryIdSave,categoryNameSave, eventCountSave, isActiveBoolean);
//
//        Gson gson = new Gson();
//        Type type = new TypeToken<ArrayList<CategoryItem>>() {}.getType();
//
//        if (json == null){
//            categoryData = new ArrayList<>();
//        } else {
//            categoryData = gson.fromJson(json, type);
//        }
//        categoryData.add(categoryItem);
//
//        String dbStr = gson.toJson(categoryData);
//        editor.putString("EVENT_CATEGORY", dbStr);
//        editor.apply();
//        finish();
//
//    }

    public String categoryIdGenerator(){

        String categoryId = "C";
        Random random = new Random();
        char c1 = (char) (random.nextInt(26) + 'A');
        char c2 = (char) (random.nextInt(26) + 'A');
        categoryId = categoryId + c1 + c2 + "-" + String.format("%d%d%d%d", random.nextInt(10), random.nextInt(10), random.nextInt(10), random.nextInt(10));
        return categoryId;
    }

    class MyBroadCastReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {

            String msg = intent.getStringExtra(SMSReceiver.SMS_MSG_KEY);

            if (msg != null) {

                if (msg.startsWith ("category:")){
                    msg = msg.substring("category:".length());



                    String[] split_string = msg.split(";",3);


                    String categoryNameMsg = split_string[0];
                    String eventCountString = split_string[1];
                    String switchStateMsg = split_string[2];
                    tvCategoryName.setText(categoryNameMsg);

                    if (split_string.length == 3) {

                        if (eventCountString != "") {


                            try {
                                int eventCountMsg;
                                eventCountMsg = Integer.parseInt(eventCountString);



                                tvEventCount.setText(eventCountString);

                                Toast.makeText(getApplicationContext(),"category: " + categoryNameMsg + " " + eventCountString + " " + switchStateMsg,Toast.LENGTH_LONG).show();
                                if (switchStateMsg.equalsIgnoreCase("true")) {
                                    activeSwitch.setChecked(true);

                                } else if (switchStateMsg.equalsIgnoreCase("false")) {
                                    activeSwitch.setChecked(false);

                                }


                            } catch (NumberFormatException e) {
                                if(!eventCountString.equals("")){
                                    Toast.makeText(context, "Invalid Message", Toast.LENGTH_SHORT).show();
                                }else{
                                    if (switchStateMsg.equalsIgnoreCase("true")) {
                                        activeSwitch.setChecked(true);

                                    } else if (switchStateMsg.equalsIgnoreCase("false")) {
                                        activeSwitch.setChecked(false);

                                    }

                                }

                            }
                        }




                    
                    }
                }
            }
        }
    }
}