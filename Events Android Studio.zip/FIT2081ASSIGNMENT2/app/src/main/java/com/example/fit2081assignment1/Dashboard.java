package com.example.fit2081assignment1;

import static android.app.ProgressDialog.show;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.view.GestureDetectorCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.lifecycle.ViewModelProvider;

import com.example.fit2081assignment1.provider.CategoryItem;
import com.example.fit2081assignment1.provider.CategoryViewModel;
import com.example.fit2081assignment1.providerEvent.EventItem;
import com.example.fit2081assignment1.providerEvent.EventViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Dashboard extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    String newEventName;
    String newEventCategoryId;
    String newEventTicketNumber;
    boolean isActiveEventBool;
    EditText tvEventName;
    EditText tvCategoryEventId;
    EditText tvTicketNumber;
    EditText tvNewEventId;
    TextView gestureTV;
    Switch newSwitchActive;
    private NavigationView navigationView;
    private DrawerLayout drawerlayout;
    private CategoryViewModel mCategoryViewModel;
    private EventViewModel mEventViewModel;
    private List<CategoryItem> categoryItems;
    private List<EventItem> data;
    // help detect basic gestures like scroll, single tap, double tap, etc
    private GestureDetectorCompat mDetector;

    // help detect multi touch gesture like pinch-in, pinch-out specifically used for zoom functionality
    private ScaleGestureDetector mScaleDetector;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.coordinatior_layout);

        tvNewEventId = findViewById(R.id.etNewEventId);
        tvEventName = findViewById(R.id.etNewEventName);
        tvCategoryEventId = findViewById(R.id.etNewCategoryId);
        tvTicketNumber = findViewById(R.id.etNewTicketNumber);
        newSwitchActive = findViewById(R.id.newSwitchActive);
        gestureTV = findViewById(R.id.gestureText);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setTitle("Assessment 3");

        navigationView = findViewById(R.id.navigationView);
        drawerlayout = findViewById(R.id.drawer_layout);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerlayout, myToolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerlayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        mEventViewModel = new ViewModelProvider(this).get(EventViewModel.class);

        mCategoryViewModel = new ViewModelProvider(this).get(CategoryViewModel.class);
        mCategoryViewModel.getAllCategory().observe(this, newData->{
            categoryItems = newData;
        });

        View touchpad = findViewById(R.id.view);
        touchpad.setOnTouchListener(new View.OnTouchListener(){
            @Override
            public boolean onTouch(View v, MotionEvent event){
                mDetector.onTouchEvent(event);
                return true;
            }
        });

        // initialise new instance of CustomGestureDetector class
        CustomGestureDetector customGestureDetector = new CustomGestureDetector();

        // register GestureDetector and set listener as CustomGestureDetector
        mDetector = new GestureDetectorCompat(this, customGestureDetector);
        mDetector.setOnDoubleTapListener(customGestureDetector);
        //MSG
        ActivityCompat.requestPermissions(this, new String[]{
                android.Manifest.permission.SEND_SMS,
                android.Manifest.permission.RECEIVE_SMS,
                android.Manifest.permission.READ_SMS
        }, 0);

        getSupportFragmentManager().beginTransaction().replace(
                R.id.frame_layout_dashboard_event, new FragmentListCategory()).commit();
        
        // FAB
        FloatingActionButton fab = findViewById(R.id.fab);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (addItem()) {
                    Snackbar.make(view, "Successfully Added A New Event", Snackbar.LENGTH_LONG)
                            .setAction("Undo", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Undo();

                                    getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout_dashboard_event, new FragmentListCategory()).commit();
                                }
                            }).show();
                }
            }
        });

        // Touch
    }

    private class CustomGestureDetector extends GestureDetector.SimpleOnGestureListener{
        @Override
        public boolean onDoubleTap(MotionEvent e){
            gestureTV.setText("Double Tap");
            addItem();
            return true;
        }
        public void onLongPress(MotionEvent e){
            gestureTV.setText("Long Press");
            tvCategoryEventId.setText("");
            tvEventName.setText("");
            tvNewEventId.setText("");
            tvTicketNumber.setText("");
            newSwitchActive.setChecked(false);
        }
    }
    public void Undo(){

        for (CategoryItem category: categoryItems){
            if(category.getCategoryId().equals(newEventCategoryId)){
                int i = category.getCategoryEventCount();
                category.setCategoryEventCount(i -1);
                mCategoryViewModel.update(category);
            }
        }


    }
    public boolean addItem(){
        newEventName = tvEventName.getText().toString();
        newEventCategoryId = tvCategoryEventId.getText().toString();
        newEventTicketNumber = tvTicketNumber.getText().toString();
        isActiveEventBool = newSwitchActive.isChecked();
        int eventTicketsInteger;
        try {
            eventTicketsInteger = Integer.parseInt(newEventTicketNumber);
        }catch (NumberFormatException e) {
            eventTicketsInteger = -1;
        }
        boolean contains = categoryIDinCategory(newEventCategoryId);

        if (!newEventName.isEmpty()){
            if (contains == true){
                String eventIdString = eventIdGenerator();
                tvNewEventId.setText(eventIdString);
                EventItem e = new EventItem(eventIdString, newEventName, newEventCategoryId, eventTicketsInteger, isActiveEventBool);
                mEventViewModel.insert(e);

                for (CategoryItem category: categoryItems){
                    if(category.getCategoryId().equals(newEventCategoryId)){
                        int i = category.getCategoryEventCount();
                        category.setCategoryEventCount(i + 1);
                        mCategoryViewModel.update(category);
                    }
                }

                getSupportFragmentManager().beginTransaction().replace(
                        R.id.frame_layout_dashboard_event, new FragmentListCategory()).commit();

                Toast.makeText(this, "Event Saved: " + eventIdString + " to " + newEventCategoryId, Toast.LENGTH_SHORT).show();
                return true;
            }
        }else {
            Toast.makeText(this, "Invalid Input Please Put In Right Values", Toast.LENGTH_LONG).show();
        }
        return false;
    }
    public String eventIdGenerator(){

        String id = "E";
        Random random = new Random();

        char c1 = (char)(random.nextInt(26)+'A');
        char c2 = (char)(random.nextInt(26)+'A');

        id = id +c1+c2+"-"+String.format("%d%d%d%d%d", random.nextInt(10), random.nextInt(10), random.nextInt(10), random.nextInt(10), random.nextInt(10));
        return id;
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.option_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){
        if (item.getItemId() == R.id.clearEventFormOption) {
            tvCategoryEventId.setText("");
            tvEventName.setText("");
            tvNewEventId.setText("");
            tvTicketNumber.setText("");
            newSwitchActive.setChecked(false);

        } else if (item.getItemId() == R.id.clearAllEvents) {
            mEventViewModel.deleteAll();
            getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout_dashboard_event, new FragmentListCategory()).commit();

        }else if(item.getItemId() == R.id.clearCategoryOption){
            mCategoryViewModel.deleteAll();

        }else if(item.getItemId() == R.id.refreshOption){
            getSupportFragmentManager().beginTransaction().replace(
                    R.id.frame_layout_dashboard_event, new FragmentListCategory()).commit();
        }
        return true;
    }
    public boolean categoryIDinCategory(String categoryID){
        for (CategoryItem category: categoryItems){
            if(category.getCategoryId().equals(categoryID)){
                return true;
            }
        }
        return false;
    }
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if(id == R.id.allCategoriesMenu) {
            Intent intent = new Intent(this, ViewAllCategories.class);
            startActivity(intent);
        } else if (id == R.id.addCategoryMenu) {
            Intent intent = new Intent(this, NewCategoryForm.class);
            startActivity(intent);
        }else if (id == R.id.viewAllEventsMenu) {
            Intent intent = new Intent(this, ViewAllEvents.class);
            startActivity(intent);
        }else if (id == R.id.logoutMenu) {
            // Logout action clearing the user session
            Intent intent = new Intent(this, LoginMenu.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            return true;
        }
        return false;
    }


    }
